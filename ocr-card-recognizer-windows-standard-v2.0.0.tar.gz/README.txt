========================================
OCR Card Recognizer - Standard Deployment
========================================

Version: v2.0.0

Quick Start:
-----------
1. Right-click install.bat and select "Run as administrator"
2. Wait for installation to complete (5-10 minutes)
3. Double-click start.bat
4. Open browser and visit: http://localhost:5000

Usage:
------
1. Upload card images
2. Click "Start Recognition"
3. Edit results if needed
4. Export to Excel

Management:
-----------
- Start service: Double-click start.bat
- Stop service: Double-click stop.bat
- Check status: Double-click check.bat

Documentation:
--------------
- README.md: Complete guide
- QUICKSTART.md: Quick start guide

Support:
--------
If you encounter issues, check logs/backend.log

========================================
