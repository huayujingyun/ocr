import { NextRequest, NextResponse } from 'next/server';
import * as XLSX from 'xlsx';

interface CardData {
  index?: number;  // 序号
  cardNumber: string;
  password: string;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { cards } = body;

    if (!cards || !Array.isArray(cards) || cards.length === 0) {
      return NextResponse.json({ error: '缺少卡片数据' }, { status: 400 });
    }

    const worksheetData = [
      ['序号', '卡号', '密码'], // 表头
      ...cards.map((card: CardData) => [card.index || '', card.cardNumber, card.password]), // 数据行
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

    // 设置列宽
    worksheet['!cols'] = [
      { wch: 6 },  // 序号列宽
      { wch: 20 }, // 卡号列宽
      { wch: 20 }, // 密码列宽
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, '卡片信息');

    // 生成Excel文件
    const excelBuffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });

    // 生成当前时间戳作为文件名
    const now = new Date();
    const timestamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}_${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}`;
    const filename = `卡片信息_${timestamp}.xlsx`;

    return new NextResponse(excelBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="${encodeURIComponent(filename)}"`,
      },
    });
  } catch (error) {
    console.error('生成Excel错误:', error);
    return NextResponse.json({ error: '生成Excel失败' }, { status: 500 });
  }
}
